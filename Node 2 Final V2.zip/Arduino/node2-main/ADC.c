

#include "ADC.h"
#include "encoder.h"

void Init_ADC(){
    // Enable ADC Clock
    // REG: PMC_PCER1
    // Field: PID37, 
    PMC->PMC_PCER1 = PMC_PCER1_PID37;

    // WPKEY: 0x50574D
    // Disabled by default?
    //ADC->ADC_WPMR = ADC_WPMR_WPKEY(0x414443) 

    // ADC CONTROLL REGISTER
    // REG: ADC_CR
    // Field: SWRST
    ADC->ADC_CR = ADC_CR_SWRST;

    // Freerun = leser av nyeste verdi
    // REG: ADC_MR
    // Field: Freerun, Prescal
    ADC->ADC_MR |= ADC_MR_FREERUN_ON;

    // Prescale = 1 for adc kan ikke være over 22Mz (Tablell 45-30 s1403)
    // REG: ADC_MR
    // Field: Prescal = 21 = 84MHz /( Prescale + 1 )*2  
    ADC->ADC_MR |= ADC_MR_PRESCAL(1);

    // Startup, tid før adc kjører
    // REG: ADC_MR 
    // Field: STARTUP (Tall = perioder)
    ADC->ADC_MR |= ADC_MR_STARTUP_SUT64;

    // Channel enable: ch 
    // REG: ADC_CHER
    // Field: CH0
    ADC->ADC_CHER = ADC_CHER_CH0; 

    
    // ADC CONTROLL REGISTER
    // REG: ADC_CR
    // Field: START
    ADC->ADC_CR = ADC_CR_START;

    // ADC CHANNEL DATA REGISTER
    // REG: ADC_CDRx
    // FIELD: DATA

    ADC->ADC_CDR[0];

    // ADC LAST CONVERTED DATA REGISTER 
    // REG: 
    // Field:
}

uint16_t ir_read_raw()
{
    return ADC->ADC_CDR[0] & 0X0FFF;
}

// Returns 1 if a new value was read, 0 if no new data is available
uint8_t Read_ADC_CH0_NonBlocking(uint32_t *adc_value) {
    // Check if the End of Conversion flag is set
    if (ADC->ADC_ISR & ADC_ISR_EOC0) {
        *adc_value = ADC->ADC_CDR[0]; // Reading clears the EOC0 flag
        return 1; 
    }
    return 0; // Move on, do other things
}

uint32_t Get_Latest_ADC_CH0(void) {
    // Returns the last completed conversion immediately.
    // Note: If called faster than the ADC sample rate, you will read the same value multiple times.
    return ADC->ADC_CDR[0];
}


uint32_t my_sensor_reading = 0;
uint32_t goals = 0; 
uint32_t UppOrDown = 0;
void adc_goal_Counter(uint32_t *my_sensor_reading){
    if(Read_ADC_CH0_NonBlocking(my_sensor_reading)){
        // printf("ADC Value: %lu \n", my_sensor_reading); 
        // If to block støy
        if(*my_sensor_reading < 100 && UppOrDown == 0){
            goals++;
            UppOrDown = 1;
            encoder_reset();
            printf("goals : %ld\n", goals);
        }
        else if (*my_sensor_reading > 300 && UppOrDown == 1 )
        {
            UppOrDown = 0;
        }
    }
}
