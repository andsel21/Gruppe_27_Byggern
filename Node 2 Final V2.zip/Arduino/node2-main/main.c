#include <stdio.h>
#include <stdarg.h>
#include "sam.h"
#include "ScaleMapping.h"

// Tor Created
#include "uart.h"
#include "can.h"
#include "time.h"

#include "encoder.h"
#include "pwm.h"
#include "ADC.h"


void SolanoidTrigger(void){
        // Set Dir to shift direction
        PIOA->PIO_CODR = PIO_PA6;
        time_spinFor(msecs(200));
        PIOA->PIO_SODR = PIO_PA6;
}


int main()
{
    SystemInit();

    WDT->WDT_MR = WDT_MR_WDDIS; //Disable Watchdog Timer

    uart_init(F_CPU, 9600);
    printf("Hello World\n\r");

    can_init((CanInit){.brp = 20, .phase1 = 4, .phase2 = 3, .propag = 5}, 1);

    Init_PWM();
    time_spinFor(msecs(1));

    Init_ADC();
    Init_Encoder();

     // Motor Direction pins
    PIOC->PIO_OER = PIO_PC23;
    PIOC->PIO_PER = PIO_PC23;

    // Solanoid Pins
    PIOA->PIO_OER = PIO_PA6;
    PIOC->PIO_PER = PIO_PA6;
    PIOA->PIO_SODR = PIO_PA6;

    extern volatile uint32_t JoyButton;

    // sample time,10 ms 
    float dt_seconds = 0.01f; 
    float max_pwm = 750.0f;
    PI_Init(&motor_pi, 2.0f, 0.5f, dt_seconds, max_pwm);


    while (1){
        servo_Position(JoyY.byte[0]);

        adc_goal_Counter(&my_sensor_reading);

        MotorUpdate(JoyX.byte[0]);

        if(JoyButton == 1){
            SolanoidTrigger();
            JoyButton = 0;
        }
        
        time_spinFor(msecs(5));
    }
    
}