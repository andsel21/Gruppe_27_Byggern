


#pragma once
#include <stdio.h>
#include <stdint.h>


static inline int16_t mapValue(int16_t value, int16_t fromMinValue, int16_t fromMaxValue, int16_t toMinValue, int16_t toMaxValue)
{
    if(value < fromMinValue){
        value = fromMinValue;
    }
    if(value > fromMaxValue){
        value = fromMaxValue;
    }
    
    double normalizedValue = (double)(value - fromMinValue) / (fromMaxValue - fromMinValue);
    int16_t mappedValue = (int16_t)(normalizedValue * (toMaxValue - toMinValue) + toMinValue);

    // Removed hardcoded 100 limits here. The bounding is already handled above.
    return mappedValue;
}