#pragma once
#include <stdio.h>
#include <stdarg.h>
#include "sam.h"
#include "ScaleMapping.h"

void Init_ADC();
uint16_t ir_read_raw();
uint8_t Read_ADC_CH0_NonBlocking(uint32_t *adc_value);
uint32_t Get_Latest_ADC_CH0(void);

uint32_t my_sensor_reading;
uint32_t goals; 
uint32_t UppOrDown;
void adc_goal_Counter(uint32_t *my_sensor_reading);