#include <stdio.h>
#include <stdarg.h>
#include "sam.h"
#include "ScaleMapping.h"

void Init_Encoder(void){
    // Enable Pins as periferals
    // TIOA6, PC25,
    // TIOB6, PC26,
    PIOC->PIO_PDR |= (PIO_PC25) | (PIO_PC26);
    PIOC->PIO_ABSR |= (PIO_PC25) | (PIO_PC26);


    // Configyre Clock TC_CV, TC_BMR TC_CCR
    // peripheral clock TC2

    // Enable TC2 Clock
    // REG: PCER1
    // Field: PID6
    PMC -> PMC_PCER1 = PMC_PCER1_PID33;

    // Capture mode, (usikker) Clock selection
    // REG: TC_CMR
    // Field: TCCLKS
    TC2 -> TC_CHANNEL[0].TC_CMR |= TC_CMR_TCCLKS_XC0;
    TC2 -> TC_CHANNEL[0].TC_CMR &= ~TC_CMR_WAVE;
    
    // Block mode
    // REG: TC_BMR
    // Field: QDEN, POSEN
    TC2 -> TC_BMR = TC_BMR_QDEN | TC_BMR_POSEN;

    // External trigger edge selection
    // REG: TC_BMR
    // Field: ETRGEDG
    TC2 -> TC_CHANNEL[0].TC_CMR |= TC_CMR_ETRGEDG_RISING;

    // External Trigger
    // REG: TC_BMR
    // Field: ABETRG
    TC2 -> TC_CHANNEL[0].TC_CMR |= TC_CMR_ABETRG;

    // Enable TC2 Clock
    // REG: TC_CCR
    // Field: CLKEN,  CLKDIS
    TC2 -> TC_CHANNEL[0].TC_CCR |= TC_CCR_CLKEN | TC_CCR_SWTRG;




    // Edge on Count mode
    // REG: TC_BMR
    // Field: EDGPHA
    // TC2 -> TC_BMR = TC_BMR_EDGPHA;

    
    // Maksimum filter Støy filter, 1 til 63
    // REG: TC_BMR
    // Field: MAXFILT
    //TC2 -> TC_BMR = TC_BMR_MAXFILT();
}

int32_t encoder_value;
int32_t encoder_read(void){
    encoder_value = TC2 -> TC_CHANNEL[0].TC_CV;
    return encoder_value;
}
void encoder_reset(void){
    TC2 -> TC_CHANNEL[0].TC_CCR = TC_CCR_SWTRG;
}
