#pragma once

typedef struct {
    float Kp;
    float Ki;
    float integral_sum;
    float dt;
    float out_max;
    float out_min;
} PI_Controller_t;


void Init_PWM();
void PI_Init(PI_Controller_t *pi, float Kp, float Ki, float dt, float limit);
float PI_Update(PI_Controller_t *pi, float reference, float measurement);
void actuate_motor(float control_signal);
void servo_Position(uint8_t positionY);


PI_Controller_t motor_pi;
uint64_t last_time;
uint64_t sample_time_ticks;

void MotorUpdate(uint8_t position);