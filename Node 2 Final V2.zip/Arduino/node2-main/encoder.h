
#pragma once
void Init_Encoder(void);

extern int32_t encoder_value;
int32_t encoder_read(void);
void encoder_reset(void);