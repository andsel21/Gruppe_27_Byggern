

#include <stdio.h>
#include <stdarg.h>
#include "sam.h"
#include "ScaleMapping.h"
#include "pwm.h"
#include "time.h"

PI_Controller_t PI_Controller;


// PWM = ATSAM3X8E pin PB13, Arduino pin D21, alternativ func, 
// frequency/duty cycle = channel 1
// PWM frequency = 50 Hz (20 ms)
// duty cycle = 0.9 and 2.1 ms, 1.5ms In middle

// Set PWM output
// Set frequency
// Set duty
// Set to outout

void Init_PWM(){
    PMC->PMC_PCER1 = 1 << (ID_PWM - 32);
    // Select Peripheral B for PB13
    PIOB->PIO_ABSR |= PIO_ABSR_P13;

    // Disable standard PIO control on PB13 to enable peripheral control
    PIOB->PIO_PDR |= PIO_PDR_P13;

    // Select Peripheral B for PB12
    PIOB->PIO_ABSR |= PIO_ABSR_P12;
        
    // Disable standard PIO control on PB13 to enable peripheral control
    PIOB->PIO_PDR |= PIO_PDR_P12;

    // Unlock user inteffrac
    // Write to REG: PWM_WPCR, Adr: 0x400940E4
    // FIELD: WPCMD bit 0-1, Set til 0
    // WPRG1: Bit 3
    // WPKEY: 0x50574D
    PWM->PWM_WPCR = PWM_WPCR_WPKEY(0x50574D) | PWM_WPCR_WPRG1 | PWM_WPCR_WPCMD(0);

    // Clock generator Config
    // Frekvens setting kansje
    // Bruker CLKA
    // Write to REG: PWM_CLK, Adr: 0x40094000
    // Slå på: DIVA = 1
    // Divider input clock til MCK: PREA: 0000 
    // PREA: 0 (Prescaler: MCK / 1)
    // DIVA: 84 (Divider: 1)
    PWM->PWM_CLK = PWM_CLK_DIVA(84) | PWM_CLK_PREA(0);

    // Select for channel 1 
    // REG: PWM_CMRx, Channel x = 1
    // Field: CPRE (prescaler)
    PWM->PWM_CH_NUM[1].PWM_CMR =  PWM_CMR_CPRE_CLKA;
    PWM->PWM_CH_NUM[0].PWM_CMR =  PWM_CMR_CPRE_CLKA;

    // Waveform Alignment Channel 1
    // Select  for channel 1 
    // REG: PWM_CMRx, Channel x = 1
    // Field: CALG, set til null Left aligned
    PWM->PWM_CH_NUM[1].PWM_CMR &= ~PWM_CMR_CALG;  // PWM_CMR_CALG;
    PWM->PWM_CH_NUM[0].PWM_CMR &= ~PWM_CMR_CALG;

    // SELECTION OF COUNTER EVENT SELECTION if calg = 1 -> Ikke brukt

    // Waveform Polarity Channel 1
    // Select for channel 1 
    // REG: PWM_CMRx, Channel x = 1
    // Field: CPOL, Chooses duty 0.9-2.1ms = high
    PWM->PWM_CH_NUM[1].PWM_CMR |= PWM_CMR_CPOL;
    PWM->PWM_CH_NUM[0].PWM_CMR |= PWM_CMR_CPOL;

    // Choice of formula values, MCK = 84 MHz
    // 20ms = CPRD*DIVA/84 MHz
    // 20*84*10^3/84 = 20*10^3
    // 0.05ms = CPRD*DIVA/84 MHz

    // Period Channel 1: Formula CPRD*DIVA/MCK
    // REG: PWM_CPRDx
    // Field: CPRD, 
    PWM->PWM_CH_NUM[1].PWM_CPRD = 20000;
    PWM->PWM_CH_NUM[0].PWM_CPRD = 4200;

    // Duty Cycle Channel 1 (upp time)
    // REG: PWM_CDTYx
    // Field: CDTY, 
    PWM->PWM_CH_NUM[1].PWM_CDTY = 1500; // 900 til 2100
    PWM->PWM_CH_NUM[0].PWM_CDTY = 0; 

    // Enable PWM on channel 1
    // REG: PWM_ENA
    // Field: CHIDx, 
    PWM->PWM_ENA = PWM_ENA_CHID1 | PWM_ENA_CHID0;

    
}


void PI_Init(PI_Controller_t *pi, float Kp, float Ki, float dt, float limit) {
    pi->Kp = Kp;
    pi->Ki = Ki;
    pi->integral_sum = 0.0f;
    pi->dt = dt;
    pi->out_max = limit;
    pi->out_min = -limit;
}

float PI_Update(PI_Controller_t *pi, float reference, float measurement) {
    float error = reference - measurement;
    float P_out = pi->Kp * error;
    
    pi->integral_sum += pi->Ki * error * pi->dt;

    if (pi->integral_sum > pi->out_max) pi->integral_sum = pi->out_max;
    else if (pi->integral_sum < pi->out_min) pi->integral_sum = pi->out_min;

    float output = P_out + pi->integral_sum;

    if (output > pi->out_max) output = pi->out_max;
    else if (output < pi->out_min) output = pi->out_min;

    return output;
}

void actuate_motor(float control_signal) {
    const uint32_t MAX_DUTY = 750;
    uint32_t duty_cycle = 0;

    if (control_signal == 0.0f) {
        PWM->PWM_CH_NUM[0].PWM_CDTYUPD = 0;
    } 
    else if (control_signal < 0.0f) {
        PIOC->PIO_SODR = PIO_PC23; 
        duty_cycle = (uint32_t)(-control_signal);
        
        if (duty_cycle > MAX_DUTY) duty_cycle = MAX_DUTY;
        PWM->PWM_CH_NUM[0].PWM_CDTYUPD = duty_cycle;
    } 
    else {
        PIOC->PIO_CODR = PIO_PC23; 
        duty_cycle = (uint32_t)(control_signal);
        
        if (duty_cycle > MAX_DUTY) duty_cycle = MAX_DUTY;
        PWM->PWM_CH_NUM[0].PWM_CDTYUPD = duty_cycle;
    }
}

void servo_Position(uint8_t positionY){
    uint16_t JoyY_mapped = 900 + ((uint16_t)positionY* 6);
    //printf("Mapped %d: \n", JoyY_mapped);

    if(JoyY_mapped < 900){
        JoyY_mapped = 900;
    }
    if(JoyY_mapped > 2100){
        JoyY_mapped = 2100;
    }
    PWM->PWM_CH_NUM[1].PWM_CDTYUPD = JoyY_mapped;
}



void MotorUpdate(uint8_t position){
    static uint64_t last_time = 0;
    uint64_t now = time_now();

    if (now - last_time < msecs(10)) {
        return;
    }
    last_time = now;
    if (time_now() - last_time >= sample_time_ticks) {
        last_time = time_now();

        // input
        uint8_t joy_x_raw = position;
        
        // Deadzone
        if (joy_x_raw >= 80 && joy_x_raw <= 120) {
            joy_x_raw = 100;
        }
        
        // Reffreance
        float ref_pos = ((float)joy_x_raw - 100.0f) * 10.0f; 
        
        // Measurement
        float measured_pos = (float)encoder_read() * 0.071f;

        // PI Control
        float u = PI_Update(&motor_pi, ref_pos, measured_pos);

        actuate_motor(u);
    }
}
