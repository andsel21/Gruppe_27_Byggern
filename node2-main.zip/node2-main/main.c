#include <stdio.h>
#include <stdarg.h>
#include "sam.h"


/*
 * Remember to update the Makefile with the (relative) path to the uart.c file.
 * This starter code will not compile until the UART file has been included in the Makefile. 
 * If you get somewhat cryptic errors referencing functions such as _sbrk, 
 * _close_r, _write_r, _fstat etc, you have most likely not done that correctly.

 * If you get errors such as "arm-none-eabi-gcc: no such file", you may need to reinstall the arm gcc packages using
 * apt or your favorite package manager.
 */
//#include "../path_to/uart.h"

// Tor Created
#include "uart.h"
#include "can.h"
#include "time.h"


// PWM = ATSAM3X8E pin PB13, Arduino pin D21, alternativ func, 
// frequency/duty cycle = channel 1
// PWM frequency = 50 Hz (20 ms)
// duty cycle = 0.9 and 2.1 ms, 1.5ms In middle

// Set PWM output
// Set frequency
// Set duty
// Set to outout

void Init_PWM(){

    PMC->PMC_PCER1 = 1 << (ID_PWM - 32);
    // Select Peripheral B for PB13
    PIOB->PIO_ABSR |= PIO_ABSR_P13;

    // Disable standard PIO control on PB13 to enable peripheral control
    PIOB->PIO_PDR = PIO_PDR_P13;


    // Unlock user inteffrac
    // Write to REG: PWM_WPCR, Adr: 0x400940E4
    // FIELD: WPCMD bit 0-1, Set til 0
    // WPRG1: Bit 3
    // WPKEY: 0x50574D
    PWM->PWM_WPCR = PWM_WPCR_WPKEY(0x50574D) | PWM_WPCR_WPRG1 | PWM_WPCR_WPCMD(0);

    // Clock generator Config
    // Frekvens setting kansje
    // Bruker CLKA
    // Write to REG: PWM_CLK, Adr: 0x40094000
    // Slå på: DIVA = 1
    // Divider input clock til MCK: PREA: 0000 
    // PREA: 0 (Prescaler: MCK / 1)
    // DIVA: 84 (Divider: 1)
    PWM->PWM_CLK = PWM_CLK_DIVA(84) | PWM_CLK_PREA(0);

    // Select for channel 1 
    // REG: PWM_CMRx, Channel x = 1
    // Field: CPRE (prescaler)
    PWM->PWM_CH_NUM[1].PWM_CMR =  PWM_CMR_CPRE_CLKA;

    // Waveform Alignment Channel 1
    // Select  for channel 1 
    // REG: PWM_CMRx, Channel x = 1
    // Field: CALG, set til null Left aligned
    PWM->PWM_CH_NUM[1].PWM_CMR &= ~PWM_CMR_CALG;  // PWM_CMR_CALG;

    // SELECTION OF COUNTER EVENT SELECTION if calg = 1 -> Ikke brukt

    // Waveform Polarity Channel 1
    // Select for channel 1 
    // REG: PWM_CMRx, Channel x = 1
    // Field: CPOL, Chooses duty 0.9-2.1ms = high
    PWM->PWM_CH_NUM[1].PWM_CMR |= PWM_CMR_CPOL;

    // Choice of formula values, MCK = 84 MHz
    // 20ms = CPRD*DIVA/84 MHz
    // 20*84*10^3/84 = 20*10^3

    // Period Channel 1: Formula CPRD*DIVA/MCK
    // REG: PWM_CPRDx
    // Field: CPRD, 
    PWM->PWM_CH_NUM[1].PWM_CPRD = 20000;

    // Duty Cycle Channel 1 (upp time)
    // REG: PWM_CDTYx
    // Field: CDTY, 
    PWM->PWM_CH_NUM[1].PWM_CDTY = 1500; // 900 til 2100

    // Enable PWM on channel 1
    // REG: PWM_ENA
    // Field: CHIDx, 
    PWM->PWM_ENA = PWM_ENA_CHID1;

    
}

void Init_ADC(){
    // Enable ADC Clock
    // REG: PMC_PCER1
    // Field: PID37, 
    PMC->PMC_PCER1 = PMC_PCER1_PID37;

    // WPKEY: 0x50574D
    // Disabled by default?
    //ADC->ADC_WPMR = ADC_WPMR_WPKEY(0x414443) 

    // ADC CONTROLL REGISTER
    // REG: ADC_CR
    // Field: SWRST
    ADC->ADC_CR = ADC_CR_SWRST;

    // Freerun = leser av nyeste verdi
    // REG: ADC_MR
    // Field: Freerun, Prescal
    ADC->ADC_MR |= ADC_MR_FREERUN_ON;

    // Prescale = 1 for adc kan ikke være over 22Mz (Tablell 45-30 s1403)
    // REG: ADC_MR
    // Field: Prescal = 21 = 84MHz /( Prescale + 1 )*2  
    ADC->ADC_MR |= ADC_MR_PRESCAL(1);

    // Startup, tid før adc kjører
    // REG: ADC_MR 
    // Field: STARTUP (Tall = perioder)
    ADC->ADC_MR |= ADC_MR_STARTUP_SUT64;

    // Channel enable: ch 
    // REG: ADC_CHER
    // Field: CH0
    ADC->ADC_CHER = ADC_CHER_CH0; 

    
    // ADC CONTROLL REGISTER
    // REG: ADC_CR
    // Field: START
    ADC->ADC_CR = ADC_CR_START;

    // ADC CHANNEL DATA REGISTER
    // REG: ADC_CDRx
    // FIELD: DATA

    ADC->ADC_CDR[0];

    // ADC LAST CONVERTED DATA REGISTER 
    // REG: 
    // Field:
}

uint16_t ir_read_raw()
{
    return ADC->ADC_CDR[0] & 0X0FFF;
}

// Returns 1 if a new value was read, 0 if no new data is available
uint8_t Read_ADC_CH0_NonBlocking(uint32_t *adc_value) {
    // Check if the End of Conversion flag is set
    if (ADC->ADC_ISR & ADC_ISR_EOC0) {
        *adc_value = ADC->ADC_CDR[0]; // Reading clears the EOC0 flag
        return 1; 
    }
    return 0; // Move on, do other things
}

uint32_t Get_Latest_ADC_CH0(void) {
    // Returns the last completed conversion immediately.
    // Note: If called faster than the ADC sample rate, you will read the same value multiple times.
    return ADC->ADC_CDR[0];
}
int main()
{
    SystemInit();

    WDT->WDT_MR = WDT_MR_WDDIS; //Disable Watchdog Timer

    //Uncomment after including uart above
    //uart_init(/*cpufreq*/, /*baud*/);
    uart_init(F_CPU, 9600);
    //printf("Hello World\n\r");
    printf("Hello World\n\r");
    
    //SCL 21 / 13
    PIOB->PIO_PER = PIO_PB13; 
    PIOB->PIO_OER = PIO_PB13; 

    //PIOB->PIO_CODR = PIO_PB13; 
    PIOB->PIO_SODR = PIO_PB13;

    can_init((CanInit){.brp = 20, .phase1 = 4, .phase2 = 3, .propag = 5}, 1);
    // Should print: CanMsg(id:1, length:7, data:{10, 0, 20, 0, 0, 240, 193})

    // Hente inn melding
    // Printe Melding på uart
    // Sende Annen Meldign Tilbake  

    CanMsg msg = {
    .id = 0x04,
    .length = 1,
    .byte = {0x00
    }
    };  
    
    Init_PWM();
    time_spinFor(msecs(1));
    // Change Duty Cycle ch. 1 when in use
    // REG: PWM_CDTYUPDx
    // Field: PWM_CDTYx
    //PWM->PWM_CH_NUM[1].PWM_CDTYUPD = 1000;

    Init_ADC();
    uint32_t my_sensor_reading = 0;
    uint32_t goals = 0; 
    uint32_t UppOrDown = 0;
    while (1)
    {
        //if(rx_flag){
            //can_tx(msg);
            //printf("I See You");
        //}
        
        //printf("Raw %d: \n", JoyX.byte[0]);
        
        uint16_t JoyX_mapped = 900 + ((uint16_t)JoyX.byte[0] * 6);
        //printf("Mapped %d: \n", JoyX_mapped);

        if(JoyX_mapped < 900){
            JoyX_mapped = 900;
        }
        if(JoyX_mapped > 2100){
            JoyX_mapped = 2100;
        }
         PWM->PWM_CH_NUM[1].PWM_CDTYUPD = JoyX_mapped;


        if(Read_ADC_CH0_NonBlocking(&my_sensor_reading)){
            printf("ADC Value: %lu \n", my_sensor_reading); 
            // If to block støy
            if(my_sensor_reading > 3000 && UppOrDown == 0){
                goals++;
                UppOrDown = 1;
                printf(goals);
            }
            else if(my_sensor_reading < 1000 && UppOrDown == 1){
                UppOrDown = 0;
            }
        }



        //can_tx(msg);
        /* code For Test LED */
       // PIOB->PIO_SODR = PIO_PB13; // Set PB13 HIGH (3.3V)
        time_spinFor(msecs(5));  // Delay 500 ms

       // PIOB->PIO_CODR = PIO_PB13; // Set PB13 LOW (0V)
        time_spinFor(msecs(5));  // Delay 500 ms
    }
    
}